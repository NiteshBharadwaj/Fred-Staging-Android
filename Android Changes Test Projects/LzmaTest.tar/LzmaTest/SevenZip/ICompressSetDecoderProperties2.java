package SevenZip;

public interface ICompressSetDecoderProperties2 {
    public boolean SetDecoderProperties2(byte[] properties);
}
