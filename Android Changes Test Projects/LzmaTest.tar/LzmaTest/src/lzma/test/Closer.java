/*
 * freenet - Closer.java Copyright © 2007 David Roden
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place - Suite 330, Boston, MA 02111-1307, USA.
 */

package lzma.test;

import java.io.Closeable;
import java.io.IOException;
import java.util.zip.ZipFile;

import android.util.Log;


/**
 * Closes various resources. The resources are checked for being
 * <code>null</code> before being closed, and every possible execption is
 * swallowed. That makes this class perfect for use in the finally blocks of
 * try-catch-finally blocks.
 * 
 * @author David &lsquo;Roden&rsquo; &lt;bombe@freenetproject.org&gt;
 * @version $Id$
 */
public class Closer {
	/**
	 * Closes the given stream.
	 * 
	 * @param outputStream
	 *            The output stream to close
	 */
	public static void close(Closeable closable) {
		if (closable != null) {
			try {
				closable.close();
			} catch (IOException e) {
				//Logger.error(Closer.class, "Error during close().", e);
				Log.e("Error during close().","output  ",e);
			}
		}
	}
	

	/**
	 * Closes the given zip file.
	 * 
	 * @param zipFile
	 *            The zip file to close
	 */
	public static void close(ZipFile zipFile) {
		if (zipFile != null) {
			try {
				zipFile.close();
			} catch (IOException e) {
				//Logger.error(Closer.class, "Error during close().", e);
				Log.e("Error during close().","zipfile  ",e);
			}
		}
	}

}
