package lzma.test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import net.contrapunctus.lzma.LzmaInputStream;

import SevenZip.Compression.LZMA.Decoder;
import SevenZip.Compression.LZMA.Encoder;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {
	//Need an input file go.txt to compress and decompress back 
	// CompressN and decompressN corresponds to newLZMACompressor.java and Compress and Decompress to oldLZMACompressor.java
	public static long compress(InputStream is, OutputStream os, long maxReadLength, long maxWriteLength) throws IOException {
		CountedInputStream cis = null;
		CountedOutputStream cos = null;
		cis = new CountedInputStream(new BufferedInputStream(is, 32768));
		cos = new CountedOutputStream(new BufferedOutputStream(os, 32768));
		Encoder encoder = new Encoder();
        encoder.SetEndMarkerMode( true );
        // Dictionary size 1MB, this is equivalent to lzma -4, it uses 16MB to compress and 2MB to decompress.
        // Next one up is 2MB = -5 = 26M compress, 3M decompress.
        encoder.SetDictionarySize( 1 << 20 );
        // enc.WriteCoderProperties( out );
        // 5d 00 00 10 00
        encoder.Code( cis, cos, -1, -1, null );
		cos.flush();
		return cos.written();
	}
        static final int propSize = 5;
    
    static final byte[] props = new byte[propSize];

    static {
        // enc.SetEndMarkerMode( true );
        // enc.SetDictionarySize( 1 << 20 );
        props[0] = 0x5d;
        props[1] = 0x00;
        props[2] = 0x00;
        props[3] = 0x10;
        props[4] = 0x00;
    }
        public static long decompress(InputStream is, OutputStream os, long maxLength, long maxCheckSizeBytes) throws IOException {
		CountedOutputStream cos = new CountedOutputStream(os);
		Decoder decoder = new Decoder();
		decoder.SetDecoderProperties(props);
		decoder.Code(is, cos, maxLength);
		return cos.written();
	}
        public static long decompressN(InputStream is, OutputStream os, long maxLength, long maxCheckSizeBytes) throws IOException {
    		byte[] props = new byte[5];
    		DataInputStream dis = new DataInputStream(is);
    		dis.readFully(props);
    		CountedOutputStream cos = new CountedOutputStream(os);
    		
    		int dictionarySize = 0;
    		for (int i = 0; i < 4; i++)
    			dictionarySize += ((props[1 + i]) & 0xFF) << (i * 8);
    		
    		//if(dictionarySize < 0) throw new InvalidCompressedDataException("Invalid dictionary size");
    		//if(dictionarySize > MAX_DICTIONARY_SIZE) throw new TooBigDictionaryException();
    		Decoder decoder = new Decoder();
    		if(!decoder.SetDecoderProperties(props)) throw new InvalidCompressedDataException("Invalid properties");
    		decoder.Code(is, cos, maxLength);
    		//cos.flush();
    		return cos.written();
    	}
        public long compressN(InputStream is, OutputStream os, long maxReadLength, long maxWriteLength) throws IOException {
    		CountedInputStream cis = null;
    		CountedOutputStream cos = null;
    		cis = new CountedInputStream(new BufferedInputStream(is, 32768));
    		cos = new CountedOutputStream(new BufferedOutputStream(os, 32768));
    		Encoder encoder = new Encoder();
            encoder.SetEndMarkerMode( true );
            int dictionarySize = 1;
            if(maxReadLength == Long.MAX_VALUE || maxReadLength < 0) {
            	//dictionarySize = MAX_DICTIONARY_SIZE;
            	//Logger.error(this, "No indication of size, having to use maximum dictionary size", new Exception("debug"));
            } 
            encoder.SetDictionarySize( dictionarySize );
            encoder.WriteCoderProperties(os);
            encoder.Code( cis, cos, maxReadLength, maxWriteLength, null );
    		//if(cos.written() > maxWriteLength)
    			//throw new CompressionOutputSizeException(cos.written());
            cos.flush();
    		//if(logMINOR)
    			//Logger.minor(this, "Read "+cis.count()+" written "+cos.written());
    		return cos.written();
    	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		File god = new File(Environment.getExternalStorageDirectory() + File.separator +"go.txt");
	       File god1= new File(Environment.getExternalStorageDirectory() + File.separator +"godam.txt");
	       File nsd = new File(Environment.getExternalStorageDirectory() + File.separator +"as.tar");
	       try{
	       FileInputStream is = new FileInputStream(god);
	       FileOutputStream os = new FileOutputStream(nsd);
	       compressN(is,os,100,100);
	       is.close();
	       os.close();
	       is = new FileInputStream(nsd);
	       os = new FileOutputStream(god1);
	       decompressN(is,os,100,100);
	       }
	       catch(IOException e) {
	    	   e.printStackTrace();
	       }
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
		
	}

}
