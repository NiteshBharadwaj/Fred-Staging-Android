package com.example.imagecreatortestcode;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.graphics.*;
import android.graphics.Paint.Style;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		int requiredWidth = 50;
		int requiredHeight = 50;
		String text = "Fuck You";
		// This is the image we are making
		
		Bitmap buffe  = Bitmap.createBitmap(requiredWidth, requiredHeight, Bitmap.Config.ARGB_4444);
		Canvas g = new Canvas(buffe);
		Paint paint = new Paint();
		paint.setAntiAlias(false);
	    paint.setStrokeWidth(1);
	    Typeface tf = Typeface.create(Typeface.DEFAULT,1);
	    paint.setTypeface(tf);
	    Rect bounds = new Rect();
		
		// We then specify the maximum font size that fits in the image
		// For this, we start at 1, and increase it, until it overflows. This-1 will be the font size
		float size = 1;
		paint.setTextSize(size);
		int width = 0;
		int height = 0;	
		while (width < requiredWidth && height < requiredHeight) {
			paint.getTextBounds(text, 0, text.length(), bounds);

			// calculate the size of the text
			width = (int) bounds.right-bounds.left;
			height = (int) bounds.top-bounds.bottom;
			Log.d("width",Integer.toString(width));
			paint.setTextSize(++size);
		}
		paint.setTextSize(size-2);
		paint.getTextBounds(text, 0, text.length(), bounds);
		width = (int) bounds.right-bounds.left;
		height = (int) bounds.top-bounds.bottom;
		// actually do the drawing

		paint.setColor(Color.BLACK);
		paint.setStyle(Style.FILL);
		g.drawRect(bounds.left, bounds.top, bounds.right, bounds.bottom, paint);
		
		paint.setColor(Color.WHITE);
		paint.setStyle(Style.FILL);

		Log.d("width",Integer.toString(width));
		// We position it to the center. Note that this is not the upper left corner
		//g2.drawString(text, (int) (requiredWidth / 2 - bounds.getWidth() / 2), (int) (requiredHeight / 2 + bounds.getHeight() / 4));
		g.drawText(text,(float) (requiredWidth / 2 - width / 2) ,(float) (requiredHeight / 2 - height/2), paint);
		// Write the data, and send the modification data to let the client cache it
		//Bucket data = ctx.getBucketFactory().makeBucket(-1);
		//OutputStream os = data.getOutputStream();
		//try {
			//ImageIO.write(buffer, "png", os);
		File file = new File(Environment.getExternalStorageDirectory() + File.separator + "go.png");
		FileOutputStream os;
		try {
			os = new FileOutputStream(file);
			buffe.compress(Bitmap.CompressFormat.PNG,90,os);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//} finally {
			//os.close();
//		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
		
	}

}

